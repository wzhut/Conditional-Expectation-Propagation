clear;
addpath(genpath('./multinv'));
addpath(genpath('./mtimesx_20110223'));
addpath(genpath('./lightspeed'));
run_dblp_r8_b1k_v2;
run_dblp_r8_b10k_v2;
run_dblp_r8_b10_v2;
run_dblp_r8_b50_v2;