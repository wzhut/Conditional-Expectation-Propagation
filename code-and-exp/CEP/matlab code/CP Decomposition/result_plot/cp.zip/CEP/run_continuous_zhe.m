clear all;
close all;
addpath_recurse('../../../../lightspeed');
addpath_recurse('./mtimesx_20110223');
addpath_recurse('./multinv');
rng(0);
rank_list = [3 5 8 10];
n = 5;
% continuous

mse_stat = zeros(4, 5);
rmse_stat = zeros(4 ,5);
time = zeros(4, 5);
dim = [200 100 200];
cfg.tol = 1e-3;
cfg.rho = 0.1;
cfg.max_iter = 500;
cfg.verbose = 1;
for nfold = 1 : n
    train = importdata(sprintf('../regression200x100x200/train-fold-%d.txt',nfold),',');
    test = importdata(sprintf('../regression200x100x200/test-fold-%d.txt',nfold),',');
    c_cpcep_zhe(train, test, 3, cfg);
%     for r = 1: length(rank_list)
%         rank = rank_list(r);
%         disp(sprintf('nfold: %d rank: %d', nfold, rank)); 
%         tic;
%         [mse, rmse, iter, diffs] = c_cpcep_zhe(train, test, rank, dim, cfg);
%         time(r, nfold) = toc;
%         mse_stat(r, nfold) = mse;
%         rmse_stat(r, nfold) = rmse;
%     end
end

save('continuous.mat');

